import {useState} from "react";
import {Route, Routes} from "react-router-dom";

import Main from "./components/Main";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Signup from "./components/Signup";
import Login from "./components/Login";
import Applications from "./components/Applications";
import AdminPanel from "./components/AdminPanel";
import CreateForm from "./components/CreateForm";

import './assets/css/styles.css'

export const BASE_URL = ' http://127.0.0.1:8000/101/api-copp';

function App() {
    const [token, setToken] = useState('');
    const [isAdmin, setIsAdmin] = useState('');
    const [isAuth, setIsAuth] = useState('');

    return (
        <>
            <Header token={token}
                    isAdmin={isAdmin}
                    isAuth={isAuth}
                    setToken={setToken}
                    setIsAdmin={setIsAdmin}
                    setIsAuth={setIsAuth}
            />
            <Routes>
                <Route path="/" element={<Main/>}/>
                <Route path="/signup" element={<Signup/>}/>
                <Route path="/login" element={<Login setToken={setToken}
                                                     setIsAdmin={setIsAdmin}
                                                     setIsAuth={setIsAuth}
                />}/>
                <Route path="/apps" element={<Applications token={token}/>}/>
                <Route path="/admin" element={<AdminPanel token={token}/>}/>
                <Route path="/create" element={<CreateForm token={token}/>}/>
            </Routes>
            <Footer/>
        </>

    );
}

export default App;
