import {useEffect, useState} from "react";
import {BASE_URL} from "../App";

const AdminPanel = (props) => {
    const [apps, setApps] = useState([]);
    const [auto, setAuto] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        getApps()
        document.title = 'Админ панель'
    }, [])

    const getApps = () => {
        fetch(`${BASE_URL}/applications`, {
            method: 'GET',
            headers: {'Content-Type': 'application/json'},
        })
            .then(data => data.json())
            .then(info => setApps(info.data))
    }

    const changeStatus = (status,id) => {
        fetch(`${BASE_URL}/admin/${id}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${props.token}`
            },
            body: JSON.stringify({status})
        })
        .then(data => data.json()) 
        .then(info => setApps(apps.map(app => { 
        if (app.id === id){ 
            console.log(info.data.status)
            return {...app, status: info.data.status} 
        } else { 
            return app 
        } 
    }))) 
     
  } 
 
    

    const deleteApp = (id) => {
        fetch(`${BASE_URL}/admin/${id}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${props.token}`
            },
        })
        setApps(apps.filter(app => app.id !== id))
    }

    const printApps = apps.map(app => {
        return (
            <div className='apps__block' key={app.id}>
                <div className='apps__textBlock'>
                    <p className='apps__status'>{app.auto_num}</p>
                    <p className='apps__status'>{app.status}</p>
                    <p className='apps__statusblock'>
                        <p className='apps__changeStatus' onClick={()=>changeStatus(2,app.id)}>Agree</p> 
                        <p className='apps__name'>|</p>
                        <p className='apps__changeStatus' onClick={()=>changeStatus(3,app.id)}>Rejectt</p>
                    </p>
                </div>
                <hr/>
                <p className='apps__name'>Имя: {app.name}</p>
                <p className='apps__description'>Описание: {app.description}</p>
                <p className='apps__status apps__delete' onClick={() => deleteApp(app.id)}>Удалить</p>
            </div>
        )
    })

    const filterAuto = (event) => {
        
        if (auto === '') {
            getApps()
        } else {
            console.log(auto)
            setApps(apps.filter(app => app.auto_num === auto))
        }
    }

    return (
        <section className='main'>
            <div className='container'>
                <div className='main__wrap'>
                    <h1 className='main__title'>Админ панель</h1>
                    <input className={'login__input app__input'}
                           value={auto}
                           placeholder="Введите номер авто"
                           onChange={(event) => setAuto(event.target.value)}
                    />
                    <button onClick={event => filterAuto(event)}>поиск</button>
                    <p className='error'>{error}</p>
                    <div className='main__appsBlock'>
                        {printApps}
                    </div>
                </div>
            </div>
        </section>
    )
}
export default  AdminPanel;