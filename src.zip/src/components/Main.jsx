import {useEffect, useState} from "react";
import {BASE_URL} from "../App";

const Main = () => {
    const [apps, setApps] = useState([]);
    const [auto, setAuto] = useState('');

    useEffect(() => {
        getApps()
        document.title = 'Все заявки'

    }, [])

    const getApps = () => {
        fetch(`${BASE_URL}/applications`, {
            method: 'GET',
            headers: {'Content-Type': 'application/json'},
        })
            .then(data => data.json())
            .then(info => setApps(info.data))
    }

    const printApps = apps.map(app => {
        return (
            <div className='apps__block'  key={app.id}>
                <div className='apps__textBlock'>
                    <p className='apps__status'>{app.auto_num}</p>
                    <p className='apps__status'>{app.status}</p>
                </div>
                <hr/>
                <p className='apps__name'>Имя: {app.name}</p>
                <p className='apps__description'>Описание: {app.description}</p>
            </div>
        )
    })
    const filterAuto = (event) => {
        setAuto(event.target.value)
        if (auto === '') {
            getApps()
        } else {
            console.log(auto)
            setApps(apps.filter(app => app.auto_num === auto))
        }
    }

    return (
        <section className='main'>
            <div className='container'>
                <div className='main__wrap'>
                    <h1 className='main__title'>Все заявки</h1>
                    <input className={'login__input app__input'}
                           value={auto}
                           placeholder="Введите номер авто"
                           onChange={(event) => filterAuto(event)}
                    />
                     <button onClick={event => filterAuto(event)}>поиск</button>
                    <div className='main__appsBlock'>
                        {printApps}
                    </div>
                </div>
            </div>
        </section>
    )
}

export default Main