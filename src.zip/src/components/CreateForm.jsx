import {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom";
import {BASE_URL} from "../App";

const CreateForm = (props) => {
    const [name, setName] = useState('');
    const [autoNum, setAutoNum] = useState('');
    const [description, setDescription] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate()

    useEffect(() => {
        document.title = 'Создать заявление'
    }, [])

    const inputsData = [
        {
            value: name,
            onChange: (e) => setName(e.target.value),
            placeholder: "Имя",
            text: "Введите имя",
            type: 'text',
        },
        {
            value: autoNum,
            onChange: (e) => setAutoNum(e.target.value),
            placeholder: "Номер авто",
            text: "Введите нгомер авто",
            type: 'text',
        },
    ]

    const createApp = (event) => {
        event.preventDefault()
        fetch(`${BASE_URL}/application`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${props.token}`
            },
            body: JSON.stringify({name, auto_num: autoNum, description}),
        })
            .then(data => data.json())
            .then(info => {
                if (info.data) {
                    navigate('/apps')
                } else {
                    setError(info.error.message)
                }
            })
    }

    const printInputs = inputsData.map(item => {
        return (
            <label className="login__label" key={item.id}>{item.text}
                <input
                    value={item.value}
                    onChange={item.onChange}
                    placeholder={item.placeholder}
                    className="login__input"
                    type={item.type}
                />
            </label>
        )
    })

    return (
        <section className='create'>
            <div className='container'>
                <div className='create__wrap'>
                    <form className='login__form'>
                        <h1 className='login__title'>Сформировать заявление</h1>
                        {printInputs}
                        <textarea value={description}
                                  className='create__textarea'
                                  placeholder={'Введите описание...'}
                                  onChange={(e) => setDescription(e.target.value)}/>
                        <button className='login__btn'
                                onClick={createApp}>Отправить
                        </button>
                    </form>
                    <p className='error'>{error}</p>
                </div>
            </div>
        </section>
    )
}

export default CreateForm