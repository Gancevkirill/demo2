import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { BASE_URL } from "../App";

const Signup = (props) => {
    const [login, setLogin] = useState('');
    const [fio, setFio] = useState('');
    const [phone, setPhone] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate()

    useEffect(() => {
        document.title = 'Регистрация'
    }, [])

    const inputsData = [
        {
            value: fio,
            onChange: (e) => setFio(e.target.value),
            placeholder: "ФИО",
            text: "Введите ФИО",
            type: 'text',
        },
        {
            value: email,
            onChange: (e) => setEmail(e.target.value),
            placeholder: "Email",
            text: "Введите email",
            type: 'email',
        },
        {
            value: login,
            onChange: (e) => setLogin(e.target.value),
            placeholder: "Логин",
            text: "Введите логин",
            type: 'text',
        },
        {
            value: phone,
            onChange: (e) => setPhone(e.target.value),
            placeholder: "Телефон",
            text: "Введите номер телефона",
            type: 'text',
        },
        {
            value: password,
            onChange: (e) => setPassword(e.target.value),
            placeholder: "Пароль",
            text: "Введите пароль",
            type: 'password',
        },
    ]

    const printInputs = inputsData.map(item => {
        return (
            <label className="login__label" key={item.id}>{item.text}
                <input
                    value={item.value}
                    onChange={item.onChange}
                    placeholder={item.placeholder}
                    className="login__input"
                    type={item.type}
                />
            </label>
        )
    })

    const log_in = (event) => {
        event.preventDefault()
        fetch(`${BASE_URL}/signup`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({login, password, phone, email, fio}),
        })
            .then(data => data.json())
            .then(info => {
                if (info.data) {
                    navigate('/login')
                } else {
                    setError(info.error.message)
                }
            })
    }

    return (
        <section className="login">
            <div className="container">
                <div className="login__wrap">
                    <form className='login__form'>
                        <h1 className='login__title'>Зарегистрироваться</h1>
                        {printInputs}
                        <button className='login__btn' onClick={log_in}>Отправить</button>
                    </form>
                    <p className='error'>{error}</p>
                </div>
            </div>
        </section>
    );
}

export default Signup;
