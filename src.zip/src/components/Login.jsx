import {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom";
import {BASE_URL} from "../App";

const Login = (props) => {
    const [login, setLogin] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate()

    useEffect(() => {
        document.title = 'Авторизация'
    }, [])

    const inputsData = [
        {
            value: login,
            onChange: (e) => setLogin(e.target.value),
            placeholder: "Логин",
            text: "Введите логин",
            type: 'text',
        },
        {
            value: password,
            onChange: (e) => setPassword(e.target.value),
            placeholder: "Пароль",
            text: "Введите пароль",
            type: 'password',
        },
    ]

    const printInputs = inputsData.map(item => {
        return (
            <label className="login__label" key={item.id}>{item.text}
                <input
                    value={item.value}
                    onChange={item.onChange}
                    placeholder={item.placeholder}
                    className="login__input"
                    type={item.type}
                />
            </label>
        )
    })

    const log_in = (event) => {
        event.preventDefault()
        fetch(`${BASE_URL}/login`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({login, password}),
        })
            .then(data => data.json())
            .then(info => {
                if (info.data) {
                    props.setToken(info.data.user_token)
                    props.setIsAuth(true)
                    props.setIsAdmin(info.data.IsAdmin)
                    console.log(info.data.IsAdmin)
                    if (info.data.IsAdmin) {
                        navigate('/admin')
                    } else {
                        navigate('/apps')
                    }
                } else {
                    setError(info.error.message)
                }
            })
    }
    return (
        <section className="login">
            <div className="container">
            <div className='text-danger'>{error}</div>
                <div className="login__wrap">
                    <form className='login__form'>
                        <h1 className='login__title'>Авторизоваться</h1>
                        {printInputs}
                        <button className='login__btn'
                                onClick={log_in}>Отправить
                        </button>
                    </form>
                    <p className='error'>{error}</p>
                </div>
            </div>
        </section>
    )
}

export default Login