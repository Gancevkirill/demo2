import {Link} from "react-router-dom";
import {BASE_URL} from "../App";

const Header = (props) => {
    const logout = (event) => {
        event.preventDefault();
        fetch(`${BASE_URL}/logout`, {
            method: "GET",
            headers: {'Content-Type': 'application/json'},
        })
            .then(data => data.json())
            .then(() => {
                props.setToken('')
                props.setIsAdmin(false)
                props.setIsAuth(false)
                window.location.href = '/'
            })
    }

    return (
        <header className="header">
            <div className='container'>
                <div className='header__wrap'>
                    <Link to={'/'} className='header__logo'>LOGO</Link>
                    <nav className='header__nav'>
                        {
                            props.isAuth ? <>
                                {props.isAdmin ? <>
                                    <Link to='/admin' className='header__link'>Админ панель</Link>
                                </> : <>
                                    <Link to='/apps' className='header__link'>Мои заявки</Link>
                                    <Link to='/create' className='header__link'>Создать заявку</Link>
                                </>
                                }
                                <Link to='/' onClick={logout} className='header__link'>Выйти</Link>
                            </> : <>
                                <Link to='/login' className='header__link'>Войти</Link>
                                <Link to='/signup' className='header__link'>Зарегистрироваться</Link>
                            </>
                        }
                    </nav>
                </div>
            </div>
        </header>
    )
}

export default Header