import {Link} from "react-router-dom";

const Footer = () => {
    return (
        <footer className="footer">
            <div className="container">
                <div className="footer__wrap">
                    <p className='footer__text'>Все парва защищены!</p>
                    <Link className="footer__link" to="/">Назад</Link>
                </div>
            </div>
        </footer>
    )
}

export default Footer